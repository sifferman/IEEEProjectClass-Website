
/*  script.js */


/*  Run inside body onload  */

function initialize() {
    console.log( "Page Loaded! :)" );

}




/*  cout/System.out.print replacements */

function handleConsoleLogButton() { }
function handleAlertButton() { }





/*  Date reciever */
/* https://www.w3schools.com/js/js_date_methods.asp */

// set innerhtml of the correct div and span elements according to today's date
// var date = document.getElementById( "Date" );





/*  Addition Calculator */

function handleAdditionInput() { }





/*  Frog */

// HD frog is in "_media/cowboy.jpg"





/* Change Font Style of all .note elements */
// Font-family: "'Comic Sans MS', cursive, sans-serif"

// let notes = document.getElementsByClassName( "note" );






/*  Cursor Selector */
/* https://www.w3schools.com/jsref/prop_style_cursor.asp */

// const cursors = [ "all-scroll", "cell", ... ];

/*  Run inside button onclick with "this" as parameter */
// function handleCursorButton( button ) { }





/*  Add and remove HTML elements */
/* https://www.w3schools.com/js/js_htmldom_nodes.asp */




