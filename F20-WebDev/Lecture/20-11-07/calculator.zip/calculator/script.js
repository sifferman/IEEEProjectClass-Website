
/* script.js */


/*  Variables */

var num1 = 0;
var num2 = 0;
var operation = '+';
var inputing = true;

var calculatorDisplay;

/*  Initialize */

function initialize() {
    calculatorDisplay = document.getElementById( "Calculator__Display" );
}




function handleClick( button ) {
    // alert( button.id );

    switch ( button.id ) {
        case "AC": clear();    break;
        case "PM": flipSign(); break;
        case "IN": inverse();  break;

        case "B0": inputNumber( 0 ); break;
        case "B1": inputNumber( 1 ); break;
        case "B2": inputNumber( 2 ); break;
        case "B3": inputNumber( 3 ); break;
        case "B4": inputNumber( 4 ); break;
        case "B5": inputNumber( 5 ); break;
        case "B6": inputNumber( 6 ); break;
        case "B7": inputNumber( 7 ); break;
        case "B8": inputNumber( 8 ); break;
        case "B9": inputNumber( 9 ); break;

        case "DI": changeOperation( '/' ); break;
        case "MU": changeOperation( '*' ); break;
        case "SU": changeOperation( '-' ); break;
        case "AD": changeOperation( '+' ); break;

        case "EQ": equals(); break;
        
        default: break;
    }
    calculatorDisplay.innerHTML = num2.toString();
    // console.log( num1 );
    // console.log( num2 );

}

function clear() {
    num1 = 0;
    num2 = 0;
}
function flipSign() {
    num2 *= -1;
    inputing = false;
}
function inverse() {
    num2 = 1 / num2;
    inputing = false;
}


function inputNumber( digit ) {
    if ( !inputing ) {
        num2 = digit;
        inputing = true;
    } else {
        num2 = 10*num2 + digit;
    }
}

function changeOperation( operator ) {
    equals();
    operation = operator;
}
function equals() {
    let temp = num2;
    switch ( operation ) {
        case '/': num2 = num1 / num2; break;
        case '*': num2 = num1 * num2; break;
        case '-': num2 = num1 - num2; break;
        case '+': num2 = num1 + num2; break;
    
        default: break;
    }
    if ( inputing ) {
        num1 = temp;
        inputing = false;
    }

}
