
/*  script.js */


/*  Global Variables */

/* Addition Calculator */
var addInput1;
var addInput2;
var addOutput;

/* Frog */
var frogIsHD = false;

/* Change Font Style of all .note elements */
var notesAreComicSans = false;

/*  Cursor Selector */
var body;

/*  Add and remove HTML elements */
var boxContainer;



/*  Run inside body onload  */

function initialize() {
    // console.log( "Page Loaded! :)" );

    /*  cout/System.out.print replacements */
    noticeDate();

    /* Addition Calculator */
    addInput1 = document.getElementById( "Addition-Input__1" );
    addInput2 = document.getElementById( "Addition-Input__2" );
    addOutput = document.getElementById( "Addition-Output" );
    handleAdditionInput();

    /*  Cursor Selector */
    body = document.getElementsByTagName( "body" )[0];
    
    /*  Add and remove HTML elements */
    boxContainer = document.getElementById( "Box-Container" );
}




/*  cout/System.out.print replacements */

function handleConsoleLogButton() {
    console.log( "Hello, World!" );
}
function handleAlertButton() {
    alert( "Hello, World!" );
}





/*  Date reciever */
/* https://www.w3schools.com/js/js_date_methods.asp */

// set innerhtml of the correct div and span elements according to today's date
// var date = document.getElementById( "Date" );

function noticeDate() {
    let date = new Date();
    let pageDate = document.getElementById( "Date" );
    let pageRan = document.getElementById( "Ran" );
    
    pageDate.innerHTML = date.getMonth()
                        + "/" + date.getDate()
                        + "/" + date.getFullYear();

    let ran = ( parseInt( date.getMonth() ) + 5 )
            * ( parseInt( date.getDate() ) + 5 )
            * ( parseInt( date.getFullYear() ) + 5 )
            * 73;
    ran %= 111;

    pageRan.innerHTML = ran;
}





/*  Addition Calculator */

function handleAdditionInput() {
    addOutput.innerHTML = parseInt( addInput1.value )
                        + parseInt( addInput2.value );
}





/*  Frog */

function HDifyFrog() {
    if ( !frogIsHD ) {
        frogIsHD = true;

        let frogImage = document.getElementById( "Frog" );
        frogImage.src = "_media/cowboy.jpg";

    }
}






/* Change Font Style of all .note elements */

function makeNotesComicSans() {
    if ( !notesAreComicSans ) {
        notesAreComicSans = true;
        
        let notes = document.getElementsByClassName( "note" );
        for ( let i = 0; i < notes.length; i++ )
            notes[i].style.fontFamily = "'Comic Sans MS', cursive, sans-serif";

    }
}






/*  Cursor Selector */
/* https://www.w3schools.com/jsref/prop_style_cursor.asp */

const cursors = [ "auto",
                  "all-scroll",
                  "cell", 
                  "n-resize", 
                  "copy", 
                  "zoom-in", 
                  "progress"
                ];

/*  Run inside button onclick with "this" as parameter */
function handleCursorButton( button ) {
    let num = parseInt( button.value );
    body.style.cursor = cursors[num];
}






/*  Add and remove HTML elements */
/* https://www.w3schools.com/js/js_htmldom_nodes.asp */

function handleAddButton() {
    let box = document.createElement( "div" );
    box.className = "box";
    boxContainer.appendChild( box );
}
function handleRemoveButton() {
    let boxes = document.getElementsByClassName( "box" );
    if ( boxes.length != 0 )
        boxContainer.removeChild( boxes[ boxes.length - 1 ] );
}
