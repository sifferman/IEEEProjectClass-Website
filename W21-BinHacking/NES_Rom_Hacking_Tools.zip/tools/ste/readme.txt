English translation of the tool + readme.txt by Eden GT.
Some translations changes are made to add further details to already obsolete information.

+-------+----------------------------------------+
| Name  | SMB Title Editor                    |
| Ver   | 0.20                                   |
| Author  | Beta                                 |
| HP Name  | βetaWorld                             |
| URL   | http://betaworld.hp.infoseek.co.jp/    |
| Mail  | betaworld@infoseek.jp                  |
+-------+----------------------------------------+

+-------------------------------------------------------------------+

+File information+

SmbTitleEditor (English)  :Main program
readme.txt            :This file
col.dat             :Palette color data (Please put it in the same folder directory)
adr.dat             :Internal data (Please put it in the same folder directory)
g_kit.dll           :Necessary to run the software (place it in the same folder directory, written by YY)
+-------------------------------------------------------------------+

+ Usage explanation +

Choose between "Attribute mode" and "Overwrite mode".
Overwrite mode allows you to draw on the title screen while left-clicking using the available BG tiles at your depository. Right-clicking erase tiles.
Attribute mode allows you to change the palette attributes of the title.
0 to 3 indicates each palette pointer, with -1 indicating no setting. Right click to swap between palettes.

When the creation is completed, click the "Hex Output" button
Make sure it fits within 314 ($13A) bytes. An error will pop up if it exceeds that limit.
You can choose to save the hex data of the title with the save button on the newly displayed screen.
You can also load previously saved title data with the "Open Hex Data" button.

To save the ROM, close the sub screen and click the "Save ROM" button on the main screen to perform the changes.

+-------------------------------------------------------------------+

+ About the "adr.dat" file +

This file contains the start address of the title data, its length value, and the CHR address.
By changing this value, you open ROMs that have been processed through expansion mappers.
If you do not understand what it does, it is better not to fiddle around with it.

How to modify:
First, open the adr.dat file with a text editor. Then rewrite and save values.
1st row: Data size
2nd row: Data start address
3rd row: CHR start address
If you put '$' at the beginning, it will be hexadecimal, otherwise it will be all decimal.
+-------------------------------------------------------------------+

+ Nota Bene +

This software is used for editing the SMB1 title screen.
Please use it for a clean, 40976-byte ROM.
If you accidentally corrupted this ROM through the program, we cannot take responsibility.
Be sure to make a backup.
If you have any requests or bugs, please let us know by bulletin board or email. (Both BetaWorld's site and email are gone)

+-------------------------------------------------------------------+

+ Update history +

Ver 0.20 (2006/1/21)
Modification to be able to read saved binary data
The ability to specify data addresses, etc.
Other various changes and corrections

Ver 0.12 (2005/6/11)
Lighter operation (Was about to sweat)
Changed colour specification methods
Other minor changes and corrections

Ver 0.11 (2005/3/26)
Fixed a bug that "OK" can only be selected under save confirmation
Added a little explanation regarding usage

Ver 0.10 (2005/3/25)
Initial release
