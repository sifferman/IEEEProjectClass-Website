	GoldFinger
utility for any translation
h00ligan@mail.ru

fanx2: DimOK,BratWolf� & all "������" members

Keys:

ctrl-1..2	- change current table
ctrl-tab	- change input mode : HEX/CHAR

in CHAR mode:
ctrl-space	- expand string to byte(s)

in search:
space		- ?

Known TBL phrases:

*XX
*XXXX
~XX
~XXXX
/XX
/XXXX
XX=C
XXXX=C
XX=S
XXXX=S
(Nh)label              

--------------------------------------------
C	- OEM character
S	- OEM string
XX	- one hex byte
XXXX	- two hex byte
Nh	- hex offset

e.g.

*00
~0D0A
/01
/3456
02=G
03=Babysitter
1222=ComeToMe

(213h)Ammo

--------------------------------------------

history:
0.1.1.1		- first alpha test build

0.2.2.4		- [+] input !!!! 
		  [+] unknown bytes

0.3.3.5		- [+] goto
		  [+] font setup
		  [+] INI settings

0.4.4.5		- [+] colors setup
		  [+] byte to string

0.5.4.7		- [+] two bytes support

0.6.5.8		- [+] buggy search

0.7.6.9		- [+] replace
		  [+] stop bytes
		  [-] bug in unknown color
		  [+] ctrl-space !

---
x.y.z.a
 x - major version
 y - minor version
 z - release number
 a - build number
