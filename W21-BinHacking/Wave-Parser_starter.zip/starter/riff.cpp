
/* riff.cpp */

#include "riff.h"

#include <cstring>
#include <cstdio>

#include "wave_endian.h"












/*=================== struct Chunk =====================*/


RIFF::Chunk::Chunk() : ChunkSize(0) {
    memset( ChunkID, 0, 4 );
}
uint32_t RIFF::Chunk::load( const uint8_t * const buffer, const size_t buffer_size ) {
    if ( buffer_size < 8 )
        throw BadChunkFormat();

    uint32_t offset = 0;

    // load ChunkID
    memcpy( ChunkID, buffer + offset, 4 );
    offset += 4;


    // load ChunkSize
    load_le( ChunkSize, buffer, offset );

    // check if the entire chunk is in buffer
    if ( buffer_size < 8 + ChunkSize )
        throw BadChunkFormat();

    return 8 + ChunkSize;

}
uint32_t RIFF::Chunk::write( uint8_t * const buffer, const size_t buffer_size ) const {
    if ( buffer_size < 8 )
        throw BadChunkFormat();

    uint32_t offset = 0;

    // load ChunkID
    memcpy( buffer + offset, ChunkID, 4 );
    offset += 4;


    // load ChunkSize
    write_le( ChunkSize, buffer, offset );

    // check if the entire chunk is in buffer
    if ( buffer_size < offset + ChunkSize )
        throw BadChunkFormat();

    return 8 + ChunkSize;

}
void RIFF::Chunk::print() const {
    printf( "\"%c%c%c%c\" : ", ChunkID[0], ChunkID[1], ChunkID[2], ChunkID[3] );
    printf( "%d\n", ChunkSize );
}











/*=================== struct MiscChunk : public Chunk =====================*/

RIFF::MiscChunk::MiscChunk()
: Chunk(), data(0)
{ }
uint32_t RIFF::MiscChunk::load( const uint8_t * const buffer, const size_t buffer_size ) {

    uint32_t size = ((Chunk*)(this))->load( buffer, buffer_size );

    if ( data )
        delete [] data;

    data = new uint8_t[ ChunkSize ];


    /* TO DO 1 */


    return size;
}
uint32_t RIFF::MiscChunk::write( uint8_t * const buffer, const size_t buffer_size ) const {

    uint32_t size = ((Chunk*)(this))->write( buffer, buffer_size );


    /* TO DO 2 */


    return size;
}
RIFF::MiscChunk::~MiscChunk() {
    if ( data )
        delete [] data;
    data = 0;
}
void RIFF::MiscChunk::print_data( uint32_t num ) const {
    num = std::min( ChunkSize, num );
    for ( uint64_t i = 0; i < num; i++ )
        printf( "%c", data[i] );
    printf("\n");
}











/*=================== struct FormatChunk : public Chunk =====================*/

RIFF::FormatChunk::FormatChunk()
: Chunk(),
  AudioFormat(0),
  NumChannels(0),
  SampleRate(0),
  ByteRate(0),
  BlockAlign(0),
  BitsPerSample(0)
{}
uint32_t RIFF::FormatChunk::load( const uint8_t * const buffer, const size_t buffer_size ) {

    uint32_t size = ((Chunk*)(this))->load( buffer, buffer_size );


    /* TO DO 1 */


    return size;

}
uint32_t RIFF::FormatChunk::write( uint8_t * const buffer, const size_t buffer_size ) const {

    uint32_t size = ((Chunk*)(this))->write( buffer, buffer_size );


    /* TO DO 2 */


    return size;

}
void RIFF::FormatChunk::printFormat() const {
    printf("AudioFormat   : %d\n", AudioFormat    );
    printf("NumChannels   : %d\n", NumChannels    );
    printf("SampleRate    : %d\n", SampleRate     );
    printf("ByteRate      : %d\n", ByteRate       );
    printf("BlockAlign    : %d\n", BlockAlign     );
    printf("BitsPerSample : %d\n", BitsPerSample  );
}










/*=================== struct DataChunk : public MiscChunk =====================*/

RIFF::DataChunk::DataChunk()
: MiscChunk()
{ }

uint32_t RIFF::DataChunk::load( const uint8_t * const buffer, const size_t buffer_size ) {
    return ((MiscChunk*)(this))->load( buffer, buffer_size );
}
uint32_t RIFF::DataChunk::write( uint8_t * const buffer, const size_t buffer_size ) const {
    return ((MiscChunk*)(this))->write( buffer, buffer_size );
}










/*=================== struct RiffChunk : public Chunk =====================*/

constexpr const uint8_t RIFF::RiffChunk::RIFF_ChunkID[4];
constexpr const uint8_t RIFF::RiffChunk::WAVE_ChunkIDs[2][4];
constexpr const uint8_t RIFF::RiffChunk::WAVE_Format[4];

RIFF::RiffChunk::RiffChunk()
: Chunk(), formatChunk(), dataChunk() {
    memset( Format, 0, 4 );
}
RIFF::RiffChunk::~RiffChunk() {
    for ( auto c_p : miscChunks ) if ( c_p ) {
            delete c_p;
            c_p = 0;
    }
}
uint32_t RIFF::RiffChunk::load( const uint8_t * const buffer, const size_t buffer_size ) {

    uint32_t size = ((Chunk*)(this))->load( buffer, buffer_size );


    /* TO DO 1 */


    return size;
}
uint32_t RIFF::RiffChunk::write( uint8_t * const buffer, const size_t buffer_size ) const {

    uint32_t size = ((Chunk*)(this))->write( buffer, buffer_size );


    /* TO DO 2 */


    return size;
}